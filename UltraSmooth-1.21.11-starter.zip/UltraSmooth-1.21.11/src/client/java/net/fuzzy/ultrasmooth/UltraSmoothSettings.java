package net.fuzzy.ultrasmooth;

/**
 * In-memory settings for the first UI prototype.
 * These switches are UI scaffolding; they do not change Minecraft rendering yet.
 */
public final class UltraSmoothSettings {
    private UltraSmoothSettings() {}

    public static boolean smartParticles = false;
    public static boolean backgroundPause = true;
    public static boolean adaptiveGraphics = false;
    public static boolean frameTimeMonitor = true;
}

package net.fuzzy.ultrasmooth;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class UltraSmoothScreen extends Screen {
    private final Screen parent;

    public UltraSmoothScreen(Screen parent) {
        super(Text.literal("UltraSmooth Settings"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int buttonWidth = Math.min(300, this.width - 40);
        int left = (this.width - buttonWidth) / 2;
        int top = Math.max(62, this.height / 2 - 82);
        int gap = 27;

        addToggle(left, top, buttonWidth, "Smart Particles",
                "When implemented, reduces low-priority particle work. Visual effects may be simplified.",
                () -> UltraSmoothSettings.smartParticles,
                value -> UltraSmoothSettings.smartParticles = value);

        addToggle(left, top + gap, buttonWidth, "Background Pause",
                "When implemented, lowers selected background work while the game window is unfocused.",
                () -> UltraSmoothSettings.backgroundPause,
                value -> UltraSmoothSettings.backgroundPause = value);

        addToggle(left, top + gap * 2, buttonWidth, "Adaptive Graphics",
                "Experimental: will adjust selected visual options based on frame-time stability.",
                () -> UltraSmoothSettings.adaptiveGraphics,
                value -> UltraSmoothSettings.adaptiveGraphics = value);

        addToggle(left, top + gap * 3, buttonWidth, "Frame-Time Monitor",
                "Shows frame-time information in a future performance overlay. Monitoring can have a small cost.",
                () -> UltraSmoothSettings.frameTimeMonitor,
                value -> UltraSmoothSettings.frameTimeMonitor = value);

        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), button -> close())
                .dimensions(left, top + gap * 4 + 8, buttonWidth, 20)
                .build());
    }

    private void addToggle(int x, int y, int width, String name, String description,
                           java.util.function.BooleanSupplier getter,
                           java.util.function.Consumer<Boolean> setter) {
        ButtonWidget button = ButtonWidget.builder(toggleText(name, getter.getAsBoolean()), widget -> {
                    boolean next = !getter.getAsBoolean();
                    setter.accept(next);
                    widget.setMessage(toggleText(name, next));
                })
                .dimensions(x, y, width, 20)
                .tooltip(Tooltip.of(Text.literal(description)))
                .build();
        addDrawableChild(button);
    }

    private static Text toggleText(String name, boolean enabled) {
        return Text.literal(name + ": " + (enabled ? "ON" : "OFF"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, 28, 0xFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal("Prototype settings — hover over a button for help"),
                width / 2, 43, 0xA0A0A0);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public void close() {
        if (client != null) {
            client.setScreen(parent);
        }
    }
}
